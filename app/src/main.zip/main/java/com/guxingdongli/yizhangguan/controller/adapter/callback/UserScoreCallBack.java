package com.guxingdongli.yizhangguan.controller.adapter.callback;

import android.widget.EditText;

/**
 * @author 余先德
 * @data 2018/3/30
 */

public interface UserScoreCallBack {
    public abstract void getNum(int position,int num);
}
