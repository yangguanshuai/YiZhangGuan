package com.guxingdongli.yizhangguan.model;

/**
 * Created by jackmask on 2018/3/14.
 */

public class SelectAddressBase {

        private String gid;
        private String name;

        public String getGid() {
            return gid;
        }

        public void setGid(String gid) {
            this.gid = gid;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
}
