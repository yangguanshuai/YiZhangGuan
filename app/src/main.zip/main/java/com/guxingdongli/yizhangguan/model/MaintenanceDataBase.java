package com.guxingdongli.yizhangguan.model;

import java.util.List;

/**
 * Created by jackmask on 2018/3/7.
 */

public class MaintenanceDataBase  {

    private List<MyRepairOrderDetailsContentBasicInfoBase> dataList;

    public List<MyRepairOrderDetailsContentBasicInfoBase> getDataList() {
        return dataList;
    }

    public void setDataList(List<MyRepairOrderDetailsContentBasicInfoBase> dataList) {
        this.dataList = dataList;
    }
}
