package com.guxingdongli.yizhangguan.util;

import android.view.View;

import java.util.Date;

/**
 * @author 余先德
 * @data 2018/3/21
 */

public interface GetTimeStrCallBack {
    public abstract void getStr(Date date, View v);
}
