package com.guxingdongli.yizhangguan.controller.adapter.callback;

import android.widget.EditText;
import android.widget.TextView;

/**
 * @author 余先德
 * @data 2018/3/17
 */

public interface StoraeHospitalDetailsCallBack {
    public abstract void getNumNew(int position,EditText num);
}
