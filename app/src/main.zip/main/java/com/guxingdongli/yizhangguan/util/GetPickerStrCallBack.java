package com.guxingdongli.yizhangguan.util;

/**
 * Created by jackmask on 2018/3/4.
 */

public interface GetPickerStrCallBack {

    public abstract void getStr(String returnStr,long id);
}
