package com.guxingdongli.yizhangguan.controller.adapter.callback;

import android.widget.TextView;

/**
 * @author 余先德
 * @data 2018/3/24
 */

public interface PushChildCallBack {
    public abstract void setStr(String view);
}
