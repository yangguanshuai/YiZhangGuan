package com.guxingdongli.yizhangguan.controller.adapter.callback;

/**
 * Created by jackmask on 2018/3/5.
 */

public interface AssetsRepairCallBack {

    public abstract void selectItem(int position,boolean type);
}
