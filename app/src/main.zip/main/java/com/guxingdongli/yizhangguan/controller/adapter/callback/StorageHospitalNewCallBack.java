package com.guxingdongli.yizhangguan.controller.adapter.callback;

/**
 * @author 余先德
 * @data 2018/4/13
 */

public interface StorageHospitalNewCallBack {
    public abstract void click(int position,String gid);
}
