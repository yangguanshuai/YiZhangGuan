package com.guxingdongli.yizhangguan.util;

import android.util.Log;

/**
 * Created by Administrator on 2018/6/12 0012.
 */

public class LogUtils {
    public static void debug(String s){
        Log.d("debug_ygs",s);
    }


    public static void debugerr(String s){
        Log.e("debug_ygs",s);
    }
}
