package com.guxingdongli.yizhangguan.controller.adapter.callback;

import android.widget.EditText;

/**
 * @author 余先德
 * @data 2018/3/22
 */

public interface EquipmentDynamicAdapterCallBack {
    public abstract void getNumNew(int position,String guie,boolean selectCon);
}
